# Building & Running InfoGenie

InfoGenie is a hybrid app: **Next.js (App Router, TypeScript)** is the front door,
proxying everything it doesn't own (the legacy SPA, all static assets, and the
entire `/api/*` surface) to an **Express** server. See `replit.md` for the full
architecture.

- **Node:** `>= 20` (built and verified on Node 24).
- **Database:** PostgreSQL (via `DATABASE_URL`).

---

## 1. Install dependencies

> ⚠️ **Off-Replit gotcha.** This project was developed on Replit, and the
> committed `package-lock.json` pins every dependency to Replit's internal
> registry (`package-firewall.replit.local`). That host only resolves *inside*
> Replit, so a plain `npm install` on any other machine fails with `ENOTFOUND`
> and npm may abort with `Exit handler never called!`.

**On Replit:** just `npm install` — the internal registry is reachable.

**Anywhere else (local/CI):** ignore the pinned lockfile and install from public npm:

```bash
rm -rf node_modules package-lock.json
npm install --registry=https://registry.npmjs.org/
```

Puppeteer's Chromium download isn't needed to build. To skip it:

```bash
PUPPETEER_SKIP_DOWNLOAD=true npm install --registry=https://registry.npmjs.org/
```

---

## 2. Configure environment

```bash
cp .env.example .env
```

Only **four** variables are required to boot; everything else is optional and
unlocks a specific integration (see `.env.example` for the full annotated list,
and the "Complete API, LLM & Token Reference" doc for where to obtain each key).

| Variable | Purpose |
|---|---|
| `CREDENTIAL_ENCRYPTION_KEY` | 32-byte AES-256-GCM key for the credential vault. Generate: `openssl rand -base64 32`. **App will not boot without it.** |
| `SESSION_SECRET` | Signs the `infogenie.sid` session cookie. Generate: `openssl rand -base64 32`. |
| `DATABASE_URL` | PostgreSQL connection string. |
| `INFOGENIE_API_KEY` | Platform API gate key (programmatic clients + LLM quota). |

Third-party API keys can also be added at runtime by an admin via
**Manage → Settings → 🔑 Platform APIs** (stored encrypted in `platform_api_keys`).
Database values override env vars.

---

## 3. Build

```bash
npm run build:next        # -> next build (production build of the React/Next layer)
```

A successful build ends with a route table and writes `.next/BUILD_ID`. The
build compiles, type-checks, and lints the whole app; it does **not** require
the database or secrets (those are only needed at runtime).

---

## 4. Run

**Production** (Next.js front door on `PORT`, Express internal on `EXPRESS_PORT`):

```bash
npm run build:next
npm start                 # -> scripts/start.js (spawns Express + `next start`)
```

**Development** (hot reload):

```bash
npm run dev               # -> scripts/dev.js (Express on 8000 + Next dev on 5000)
```

> Note: `next dev` and `next start` cannot share the `.next` directory — don't
> run the dev workflow while exercising the prod launcher locally.

Legacy Express-only path (no Next): `npm run start:express` / `npm run dev:express`.

---

## 5. Lint & test

```bash
npm run lint              # fabrication-marker + CSS (important/specificity) checks
npm test                  # node --test suite under test/
```

---

## Troubleshooting

- **`ENOTFOUND package-firewall.replit.local` / `Exit handler never called!`** —
  the Replit-pinned lockfile. Fix per step 1 (remove lockfile, install from
  public npm).
- **`next: command not found`** — the `.bin` shims didn't get written (often a
  side effect of the failed install above). Reinstall cleanly per step 1, or run
  the CLI directly: `node node_modules/next/dist/bin/next build`.
- **Build fails on ESLint `react/no-unescaped-entities`** — an unescaped `'`/`"`
  in JSX text; escape it as `&apos;` / `&quot;`. (Warnings — `<img>` vs
  `<Image>`, hook deps, `no-css-tags` — do **not** fail the build.)
- **Boots then crashes on start** — a required env var is missing; most commonly
  `CREDENTIAL_ENCRYPTION_KEY`. Check `.env` against the required four above.
