{pkgs}: {
  deps = [
    pkgs.chromium
  ];
}
